#include <iostream> // lets us print to console
#include <fstream> // lets us read the GPA report
#include <sstream> // lets us split lines using stringstream
#include <string> // lets us use strings

int main() {
    // creates constant variable so code is easier to find
    // CHANGE THIS VARIABLE NUMBER BASED ON WHATEVER GPA YOU WANT AND ABOVE
    const double GPA_THRESHOLD = 3.5;

    // opens file
    std::ifstream file("gradereport2025.csv");

    if (!file.is_open()) {
        //edge case, checks to see if there is an error and stops program before failing
        std::cout << "Error opening file" << std::endl;
        return 1;
    }

    std::string line;

    // skips first lines of file
    std::getline(file, line);
    std::getline(file, line);
    std::getline(file, line);

    // reads each student row by row
    while (std::getline(file, line)) {
        //breaks row apart by commas
        std::stringstream ss(line);

        std::string column; // stores each column
        std::string lastName; // stores lastname column
        std::string firstName; // stores firstname column
        std::string gpaStr; // stores gpa column

        int columnIndex=0; // keeps track of which column we are on, like an index

        // reads each column separated by commas
        while (std::getline(ss, column, ',')) {

            //sets each variable equal to the corresponding column
            if (columnIndex == 3) {
                lastName = column;
            }
            if (columnIndex == 4) {
                firstName = column;
            }
            if (columnIndex == 6) {
                gpaStr = column;
            }

            columnIndex++; // goes to the next column
        }

        // if gpa cell is empty, skip
        if (gpaStr.empty()) continue;

        //converts string to a number/double
        double gpa = std::stod(gpaStr);

        // if gpa >= our threshold, print name!
        if (gpa >= GPA_THRESHOLD) {
            std::cout << firstName << " " << lastName << " - GPA: " << gpa << std::endl;
        }
    }

    return 0;
}